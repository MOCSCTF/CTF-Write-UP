backup_eval = eval
backup_print = print
input = input()
if '[' in input or ']' in input:
	print('[You failed to break the jail]')
	exit(-1)
globals()['__builtins__'].__dict__.clear()
backup_print(backup_eval(input,{},{}))
